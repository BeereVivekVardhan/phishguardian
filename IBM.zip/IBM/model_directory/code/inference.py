import joblib
import os
import json
import numpy as np

def model_fn(model_dir):
    """
    Loads the model from the disk. This function is called by SageMaker.
    """
    print("Loading model from a .joblib file.")
    model = joblib.load(os.path.join(model_dir, "phishing-classifier-model.joblib"))
    return model

def input_fn(request_body, request_content_type):
    """
    Deserializes the input request. In this case, we expect JSON input.
    """
    if request_content_type == 'application/json':
        request = json.loads(request_body)
        url = request['url']
        return url
    else:
        raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model):
    """
    Generates a prediction from the model. The input is the URL from input_fn.
    """
    print(f"Received URL for prediction: {input_data}")
    
    # IMPORTANT: The feature extraction logic MUST be here.
    # This is the SIMULATED function from your notebook.
    def extract_features_from_url(url):
        print(f"🔬 Analyzing URL: {url} ... (using simulated features)")
        if "bankofamerica-secure.com" in url:
            return np.array([[-1, -1, 1, 1, -1, -1, 0, -1, -1, 1, 1, -1, -1, -1, 0, -1, 1, 1, 0, 1, 1, 1, 1, -1, -1, -1, -1, 1, 0, 1]])
        elif "googleusercontent.com/youtube.com" in url:
            return np.array([[1, -1, 1, 1, 1, -1, 0, 1, -1, 1, 1, 1, 1, 0, 0, -1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]])
        else:
            print(f"⚠️ Warning: No simulation available for '{url}'. A real feature extractor is needed.")
            # In a real scenario, you might return a default feature set or raise an error.
            # For this example, we'll return None to handle it gracefully.
            return None

    features = extract_features_from_url(input_data)
    
    if features is not None:
        prediction = model.predict(features)
        return prediction
    else:
        return np.array([-99]) # Return a special value for unknown URLs

def output_fn(prediction, accept):
    """
    Serializes the prediction result into the response body.
    """
    if prediction[0] == -99:
        result = {'prediction': 'Unknown', 'status': 'URL not simulated'}
    elif prediction[0] == -1:
        result = {'prediction': -1, 'status': 'Phishing'}
    else:
        result = {'prediction': 1, 'status': 'Legitimate'}
        
    return json.dumps(result), accept