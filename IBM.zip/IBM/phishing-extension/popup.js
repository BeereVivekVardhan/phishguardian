const API_BASE = "https://zqujemmi2m.execute-api.eu-north-1.amazonaws.com/";

// Function to display results in the popup
function showResult(text, color = "#000") {
  const el = document.getElementById("result");
  el.textContent = text;
  el.style.color = color;
}

// Runs when the popup is opened
document.addEventListener('DOMContentLoaded', () => {
  // Query for the active tab in the current window
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentTab = tabs[0];
    if (currentTab && currentTab.url) {
      // Set the input field's value to the current tab's URL
      document.getElementById("urlInput").value = currentTab.url;
    }
  });
});

// Manual URL check
document.getElementById("checkBtn").addEventListener("click", async () => {
  const url = document.getElementById("urlInput").value.trim();
  const resultDiv = document.getElementById("result");
  if (!url) {
    showResult("Please enter a URL.", "orange");
    return;
  }
  resultDiv.textContent = "Checking...";
  try {
    const res = await fetch(`${API_BASE}/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });
    if (!res.ok) throw new Error(`API HTTP ${res.status}`);
    const data = await res.json();
    if (data.prediction === -1) {
      showResult("🚨 Phishing detected!", "red");
    } else if (data.prediction === 1) {
      showResult("✅ Legitimate site", "green");
    } else {
      showResult("⚠️ Could not classify", "orange");
    }
  } catch (err) {
    showResult("Error: " + err.message, "red");
  }
});

// Simulator
document.getElementById("simulateBtn").addEventListener("click", async () => {
  const el = document.getElementById("simulateResult");
  el.textContent = "Simulating...";
  try {
    const res = await fetch(`${API_BASE}/simulate`, { method: "GET" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    el.textContent = data.message;
  } catch (err) {
    el.textContent = "Error: " + err.message;
  }
});

// Feedback functions
document.getElementById("reportBtn").addEventListener("click", () => sendFeedback("phishing"));
document.getElementById("safeBtn").addEventListener("click", () => sendFeedback("safe"));

async function sendFeedback(label) {
  const el = document.getElementById("feedbackResult");
  el.textContent = "Sending feedback...";
  try {
    const url = document.getElementById("urlInput").value.trim();
    if (!url) {
      el.textContent = "URL is required for feedback.";
      return;
    }
    const res = await fetch(`${API_BASE}/feedback`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ feedback: label, url: url })
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    el.textContent = `Feedback stored (id: ${data.id || "n/a"})`;
  } catch (err) {
    el.textContent = "Error: " + err.message;
  }
}