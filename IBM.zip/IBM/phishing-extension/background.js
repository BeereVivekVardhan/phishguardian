// Use the same API base URL as your popup
const API_BASE = "https://zqujemmi2m.execute-api.eu-north-1.amazonaws.com/";

// This listener fires whenever a tab is updated (e.g., navigation)
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  // We only want to act when the page has finished loading
  // and the tab has a valid URL (http or https)
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
    console.log(`Checking URL: ${tab.url}`);
    
    try {
      const res = await fetch(`${API_BASE}/predict`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: tab.url })
      });

      if (!res.ok) {
        console.error(`API Error: HTTP ${res.status}`);
        return; // Stop on API error
      }

      const data = await res.json();

      // If the prediction is -1 (phishing), create a notification
      if (data.prediction === -1) {
        console.log(`Phishing detected for URL: ${tab.url}`);
        showPhishingAlert(tab.url);
      } else {
        console.log(`URL is legitimate: ${tab.url}`);
      }

    } catch (err) {
      console.error("Error checking URL:", err.message);
    }
  }
});

// Function to create and show the desktop notification
function showPhishingAlert(phishingUrl) {
  chrome.notifications.create({
    type: 'basic',
    title: '🚨 Phishing Alert!',
    message: `The website "${new URL(phishingUrl).hostname}" is suspected of being a phishing site. Please be careful!`,
    priority: 2 // Make it a high-priority notification
  });
}